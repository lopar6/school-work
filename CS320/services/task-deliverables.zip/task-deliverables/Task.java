package com.mylopar6.contact;

import java.util.Random;

public class Task {
  private String ID;
  private String name;
  private String description;

  public Task(String name, String description) {

    validateString(name, "name", 10);
    validateString(description, "description", 50);
    
    this.ID = generateID();
    this.name = name;
    this.description = description;
  }

  public String getID() {
    return this.ID;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    validateString(name, "name", 10);
    this.name = name;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    validateString(description, "description", 50);
    this.description = description;
  }

  private String generateID(){
    Random random = new Random();
    String ID = String.valueOf(random.nextInt(11));
    return ID;
  }
  private void validateString(String input, String type, int maxLength){
    String errorMessage;
    if (type == "name") {
      errorMessage = "Name must be 10 characters or less";
    } else if (type == "description") {
      errorMessage = "Description must be 50 charaters or less";
    } else {
      errorMessage = "type not found";
      throw new RuntimeException(errorMessage);
    }

    if (input == null || input.length() > maxLength){
      throw new RuntimeException(errorMessage);
    }
  }
}
